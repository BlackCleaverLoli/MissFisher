# MissFisher Triggernometry 历史归档

从公开发布仓库 `BlackCleaverLoli/MissFisher` 的 git 历史里导出的 Triggernometry
触发器导出文件，共 7 份源文件、501 个不同修订，原始体积 877.2 MiB。

这些文件在 2025-12-14 的提交 `3b0c339`「废弃 Triggernometry 版本」中从仓库删除，
之后只以历史 blob 的形式留在 git 对象库里。为了让仓库不再背着这几百 MiB 重复文本，
历史被重写，对应的 blob 从历史中移除，导出成本归档包。

## 内容

- 每份源文件一个目录，目录内是按时间排序的修订。
  文件名为 `<日期>_<序号>_<blob sha1 前 8 位>.xml`。
- `manifest.csv`：每行一个修订，含源路径、目录、文件名、blob sha1、日期、
  原始字节数、引用该内容的提交数，以及最早的提交。
- `README.md`：本文件。

## 使用

```sh
tar -xJf missfisher-triggernometry-history.tar.xz
```

内容是 XML 文本，修订之间高度重复，固实压缩后整包约 1 MiB。校验单个文件归属，
可以用 `git hash-object <文件>` 比对文件名里的 sha1。

## 不含

插件发布包 `latest.zip` 的历史未保留。
